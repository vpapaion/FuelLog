package gr.vaios.fuellogger;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int VOICE_REQUEST = 100;
    private static final int AUDIO_PERMISSION_REQUEST = 101;

    private EditText kmInput;
    private EditText litersInput;
    private TextView resultText;
    private TextView historyText;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        kmInput = findViewById(R.id.kmInput);
        litersInput = findViewById(R.id.litersInput);
        resultText = findViewById(R.id.resultText);
        historyText = findViewById(R.id.historyText);

        Button voiceButton = findViewById(R.id.voiceButton);
        Button saveButton = findViewById(R.id.saveButton);
        Button clearButton = findViewById(R.id.clearButton);

        prefs = getSharedPreferences("fuel_log", MODE_PRIVATE);

        saveButton.setOnClickListener(v -> calculateAndSave());
        voiceButton.setOnClickListener(v -> startVoiceInput());
        clearButton.setOnClickListener(v -> {
            prefs.edit().remove("history").apply();
            loadHistory();
            resultText.setText("Αποτέλεσμα: -");
        });

        loadHistory();
    }

    private void calculateAndSave() {
        String kmText = kmInput.getText().toString().replace(",", ".").trim();
        String litersText = litersInput.getText().toString().replace(",", ".").trim();

        if (kmText.isEmpty() || litersText.isEmpty()) {
            Toast.makeText(this, "Συμπληρώστε χιλιόμετρα και λίτρα.", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            double km = Double.parseDouble(kmText);
            double liters = Double.parseDouble(litersText);

            if (km <= 0 || liters < 0) {
                Toast.makeText(this, "Τα χιλιόμετρα πρέπει να είναι > 0 και τα λίτρα ≥ 0.", Toast.LENGTH_SHORT).show();
                return;
            }

            double consumption = (liters / km) * 100.0;
            String result = String.format(Locale.US, "%.2f L/100 km", consumption);
            resultText.setText("Αποτέλεσμα: " + result);

            String dateTime = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(new Date());
            String entry = dateTime + " | " + km + " km | " + liters + " L | " + result;

            String oldHistory = prefs.getString("history", "");
            String newHistory = entry + "\n" + oldHistory;
            prefs.edit().putString("history", newHistory).apply();

            loadHistory();
            kmInput.setText("");
            litersInput.setText("");

        } catch (NumberFormatException e) {
            Toast.makeText(this, "Δώστε έγκυρους αριθμούς.", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadHistory() {
        String history = prefs.getString("history", "");
        if (history.isEmpty()) {
            historyText.setText("Δεν υπάρχουν εγγραφές ακόμη.");
        } else {
            historyText.setText(history);
        }
    }

    private void startVoiceInput() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, AUDIO_PERMISSION_REQUEST);
            return;
        }

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "el-GR");
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT,
                "Πείτε π.χ. τριακόσια είκοσι χιλιόμετρα και δεκαεπτά λίτρα");

        try {
            startActivityForResult(intent, VOICE_REQUEST);
        } catch (Exception e) {
            Toast.makeText(this, "Δεν βρέθηκε υπηρεσία φωνητικής αναγνώρισης.", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == VOICE_REQUEST && resultCode == RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) {
                parseVoiceText(results.get(0));
            }
        }
    }

    private void parseVoiceText(String spokenText) {
        String text = spokenText.toLowerCase(Locale.ROOT)
                .replace(",", ".")
                .replace("χιλιόμετρα", " km ")
                .replace("χιλιομετρα", " km ")
                .replace("χλμ", " km ")
                .replace("λίτρα", " l ")
                .replace("λιτρα", " l ");

        String[] parts = text.split("\\s+");
        Double km = null;
        Double liters = null;

        for (int i = 0; i < parts.length; i++) {
            Double number = tryParseNumber(parts[i]);
            if (number == null) continue;

            String next = (i + 1 < parts.length) ? parts[i + 1] : "";
            if (next.equals("km")) {
                km = number;
            } else if (next.equals("l")) {
                liters = number;
            }
        }

        // Εναλλακτικά: αν ο χρήστης πει μόνο δύο αριθμούς, π.χ. "320 17.5"
        if (km == null || liters == null) {
            ArrayList<Double> numbers = extractNumbers(text);
            if (numbers.size() >= 2) {
                km = numbers.get(0);
                liters = numbers.get(1);
            }
        }

        if (km != null) kmInput.setText(String.valueOf(km));
        if (liters != null) litersInput.setText(String.valueOf(liters));

        Toast.makeText(this, "Ακούστηκε: " + spokenText, Toast.LENGTH_LONG).show();
    }

    private ArrayList<Double> extractNumbers(String text) {
        ArrayList<Double> numbers = new ArrayList<>();
        String[] parts = text.split("\\s+");
        for (String part : parts) {
            Double n = tryParseNumber(part);
            if (n != null) numbers.add(n);
        }
        return numbers;
    }

    private Double tryParseNumber(String s) {
        try {
            return Double.parseDouble(s);
        } catch (Exception e) {
            return null;
        }
    }
}
